from django.contrib import admin
from home.models import contact

# Register your models here.
admin.site.register(contact)