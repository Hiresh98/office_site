from django.contrib import messages
from django.http.response import HttpResponse
from django.shortcuts import render, HttpResponse
from datetime import datetime
from home.models import contact
from django.contrib.messages import get_messages
from django.contrib.auth.models import User,auth



# Create your views here.


def index(request):
    
    return render(request, 'index.html', )

def about(request):
    return render(request, 'about.html', )

def services(request):
    return render(request, 'services.html', )

def jobs(request):
    return render(request, 'jobs.html', )

def projects(request):
    return render(request, 'projects.html', )

def upcoming(request):
    return render(request, 'upcoming.html', )

def login(request):
    return render(request, 'login.html', )

def register(request):
    return render(request, 'register.html', )


def contact (request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        user = User.objects.create_user(name=name,email=email,phone=phone,desc=desc)
        Contact= contact (name=name,email=email,phone=phone,desc=desc,date=datetime.today())
        messages.success(request, 'Profile details updated.')
        user.save()
        contact.save()
        print('user creater')
    
    return render(request,'contact.html', )

